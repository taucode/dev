﻿using System;

namespace Acme.Sample.Core
{
    public class CoreComponent
    {
        public CoreComponent()
        {
            Console.WriteLine("Core component created.");
        }
    }
}
