﻿using System;

namespace Acme.Sample.Core.Tests
{
    public static class TestHelper
    {
        public static void Foo()
        {
            Console.WriteLine("Hello there!");
        }
    }
}
